openssl-iOS
===========

project to build openssl static libraries for inclusion in iOS apps