var a00024 =
[
    [ "setByIntersectingSet:", "a00024.html#a6912545bf71e2f8192dcc43a19e6f774", null ],
    [ "setByMinusingSet:", "a00024.html#aa3734ceb75e12840ae7adf52fded8b5b", null ],
    [ "setByUnioningSet:", "a00024.html#a5b5fa938ecc7e4c42d4fc571ee5b6654", null ]
];