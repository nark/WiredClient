var a00005 =
[
    [ "dateAtStartOfCurrentDay", "a00005.html#a883699da17cbfe77f3767cbc4c1c4723", null ],
    [ "dateAtStartOfCurrentMonth", "a00005.html#ac8c6726c040cf1cd47670899f0d41c86", null ],
    [ "dateAtStartOfCurrentWeek", "a00005.html#adeafb54a83db5cde0bf504e61816b4a9", null ],
    [ "dateAtStartOfCurrentYear", "a00005.html#ace9034fbadaf11e1708e5e3dc8cb9101", null ],
    [ "dateAtStartOfDay", "a00005.html#a2caa9066ab79e977616e8f654d2d42ff", null ],
    [ "dateAtStartOfMonth", "a00005.html#a11f4e4da6d7e59a2b3d92bbb20309b97", null ],
    [ "dateAtStartOfWeek", "a00005.html#a569870363ee3b10b545ac1894b75f1ab", null ],
    [ "dateAtStartOfYear", "a00005.html#a3857b49ccbb3bf2a0254e81a84f9901b", null ],
    [ "dateByAddingDays:", "a00005.html#ac824f0f485ea4fba28f9b733ec86181a", null ],
    [ "isAtBeginningOfAnyEpoch", "a00005.html#a6e87ba310ca193fc4ece849160af947f", null ]
];