var a00042 =
[
    [ "initWithSelectors:", "a00042.html#a00092bc237a13e3eba51761e86623d0b", null ],
    [ "_count", "a00042.html#ac35733dd1d5b7b3d2422056f0e084ca0", null ],
    [ "_selectors", "a00042.html#a426737048881f04027bc5e12cb56cb2a", null ]
];