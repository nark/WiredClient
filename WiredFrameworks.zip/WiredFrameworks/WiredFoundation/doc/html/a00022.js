var a00022 =
[
    [ "amountOfMemory", "a00022.html#afb2a3556463e93701a9aecc2f49a4ff0", null ]
];