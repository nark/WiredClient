var a00013 =
[
    [ "setBool:forKey:", "a00013.html#a312742d8f9562df675e3476b7342ef69", null ],
    [ "setDouble:forKey:", "a00013.html#a4dafb96ec0432a7f35b555fbd8fbf360", null ],
    [ "setFloat:forKey:", "a00013.html#ab51c0e5d03967d2a72aaf21f860f9101", null ],
    [ "setInt:forKey:", "a00013.html#ae89774c80543be421110e6f48ecb3b69", null ],
    [ "setInteger:forKey:", "a00013.html#a23ae3c0dc1d681b42dd25a2f2432de2a", null ],
    [ "setUnsignedInt:forKey:", "a00013.html#ae9f0db1b720f203df4303bf5ef5722b0", null ],
    [ "setUnsignedInteger:forKey:", "a00013.html#aabe2d76f3532bf642b7410cfe0eb7d7f", null ]
];