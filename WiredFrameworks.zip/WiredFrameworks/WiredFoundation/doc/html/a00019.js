var a00019 =
[
    [ "bundle", "a00019.html#aa166bbfbfc8b7c0f1f20ca04826b122f", null ],
    [ "bundle", "a00019.html#aa166bbfbfc8b7c0f1f20ca04826b122f", null ],
    [ "cancelPreviousPerformRequestsWithTarget:selector:", "a00019.html#a649a39b5dcd008df77fa8a52c6833245", null ],
    [ "performSelector:afterDelay:", "a00019.html#a8661d2333cd4a801fce0c965d17db395", null ],
    [ "performSelectorOnce:afterDelay:", "a00019.html#add61b9791262cbfeb68c3703b5656ebe", null ],
    [ "performSelectorOnce:withObject:afterDelay:", "a00019.html#a788ae75527552a631f0340ed846abe70", null ]
];