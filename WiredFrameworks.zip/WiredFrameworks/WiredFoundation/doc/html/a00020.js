var a00020 =
[
    [ "isKindOfPropertyListSerializableClass", "a00020.html#aca335a7e2588ffb7925d9863ea412c07", null ]
];