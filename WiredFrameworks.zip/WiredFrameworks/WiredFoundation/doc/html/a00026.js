var a00026 =
[
    [ "isMainThread", "a00026.html#afd1289d243f5404572b970320fb6d8f1", null ],
    [ "mainThread", "a00026.html#a0027c50526c54faba84c7a979fc77330", null ],
    [ "threadIdentifier", "a00026.html#aab935eb796db69ab5a6e8926d55e288b", null ]
];