var a00034 =
[
    [ "addPath:", "a00034.html#acf5f5bcef61943ddeb1adf1fe671a5e5", null ],
    [ "addPath:forMode:", "a00034.html#a444389027e83c7181916724e622e9d45", null ],
    [ "notificationCenter", "a00034.html#a026c1a69a2553a983e866cf39acdf8b0", null ],
    [ "removeAllPaths", "a00034.html#ab2449f9fcb1172481dbd5a93f21b4037", null ],
    [ "removePath:", "a00034.html#a807bd49a5d9da8eeea6a33045fd9e0b1", null ],
    [ "sharedQueue", "a00034.html#a42450982857b3637d7e29eaee41d5aa4", null ],
    [ "_center", "a00034.html#a0569256cbd99f4d071b78aefcedf3a4b", null ],
    [ "_fd", "a00034.html#a84fc9be20ea47ffffda694a45183556e", null ],
    [ "_fileHandle", "a00034.html#a937ecc94abb1722243e30ba2521da11d", null ],
    [ "_files", "a00034.html#a6e7c3eff899d142c1f29baf4085e2910", null ]
];