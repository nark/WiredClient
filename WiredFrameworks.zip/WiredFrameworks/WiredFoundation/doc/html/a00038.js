var a00038 =
[
    [ "lockForReading", "a00038.html#a24329c08179f6fcb9b2275da8cbe56f0", null ],
    [ "lockForWriting", "a00038.html#a4d98456b0bcb0ee2e84018308525c316", null ],
    [ "unlock", "a00038.html#a86cfafacf48027d93339576aaf77a926", null ]
];