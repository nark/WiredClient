var a00007 =
[
    [ "boolForKey:", "a00007.html#a4473f989d655188bd0b39fbe7a7db1b5", null ],
    [ "doubleForKey:", "a00007.html#a0ee31fb8107f6715ebc6b6850187fc21", null ],
    [ "floatForKey:", "a00007.html#ae7fa3cdf6a4cba2fff1ef52caf82ec43", null ],
    [ "integerForKey:", "a00007.html#a18da100fdc0f6f800764933257e99296", null ],
    [ "intForKey:", "a00007.html#a1089aeff604dff53da1e1c3748e9c078", null ],
    [ "unsignedIntegerForKey:", "a00007.html#a7411e86ea171b77436718d24c314191f", null ],
    [ "unsignedIntForKey:", "a00007.html#a01d619bd763bda03f5df41079fab3c5c", null ]
];