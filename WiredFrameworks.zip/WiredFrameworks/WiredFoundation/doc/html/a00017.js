var a00017 =
[
    [ "numberWithTimeval:", "a00017.html#a355cec65155b10d3423a949fbbc67b56", null ],
    [ "timevalValue", "a00017.html#ab3bef8799c7b36454747a1349b30419d", null ]
];