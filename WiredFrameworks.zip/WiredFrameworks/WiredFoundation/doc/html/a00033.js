var a00033 =
[
    [ "fileDescriptor", "a00033.html#a9b2f224becfb050b0a410e2d0232a664", null ],
    [ "initWithPath:fileDescriptor:", "a00033.html#ac977fc182c9e0da9f14ab608b0c39d70", null ],
    [ "path", "a00033.html#acb02f14d2a0584ed344708d73b567072", null ],
    [ "_fd", "a00033.html#a551b6ee01b83976b7d4a945e5cbb4cde", null ],
    [ "_path", "a00033.html#afd371be39a3116d74dedd27c68247ece", null ]
];