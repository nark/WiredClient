var a00008 =
[
    [ "errorByAddingUserInfo:", "a00008.html#abc4a8159854e8f60f8bd370543470b32", null ],
    [ "errorWithDomain:code:", "a00008.html#affe15d3d76a4d875364c5ce74dcd25a0", null ],
    [ "errorWithDomain:code:argument:", "a00008.html#a583d0b8c8d96b37254fdcad4b40323be", null ],
    [ "initWithDomain:code:", "a00008.html#acd577f792f07f0ff410d331f0fa13be0", null ]
];