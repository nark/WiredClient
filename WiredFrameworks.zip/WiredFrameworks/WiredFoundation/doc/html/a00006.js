var a00006 =
[
    [ "dateComponentsWithYear:month:day:hour:minute:second:", "a00006.html#a046463e82200912e5e8c7d10013537d9", null ],
    [ "initWithYear:month:day:hour:minute:second:", "a00006.html#a4cee2d6aa68d5b227fd9fcad59a8646e", null ]
];