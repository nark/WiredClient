var a00018 =
[
    [ "deepMutableCopy", "a00018.html#a02a98bc517bba4bbb58b051296e740e9", null ],
    [ "deepMutableCopyWithZone:", "a00018.html#ae2f032cbcb8dae721b150e8a056aa091", null ]
];