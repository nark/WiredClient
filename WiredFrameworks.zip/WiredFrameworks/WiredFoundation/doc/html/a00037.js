var a00037 =
[
    [ "tryLockForReading", "a00037.html#a1c6259c3d0b4ad89571a66924d7c7828", null ],
    [ "tryLockForWriting", "a00037.html#a9e64a71929fa505ee3be82af1c0e8f8b", null ],
    [ "_lock", "a00037.html#a0d82183275c67ebb291aeab5eb5fb132", null ]
];